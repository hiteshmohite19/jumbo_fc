package com.hitesh.ofcwork;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class Flights extends AppCompatActivity implements RecyclerViewAdapter.ClickListener, RecyclerViewAdapter.GetMonth {
    Calendar calendar;
    String TAG="project";
    String date,day,month,year;
    String selectedDate;
    RecyclerView recyclerView;
    RecyclerViewAdapter recyclerViewAdapter;
    TextView monthVal,yearVal,dDate;
    int price=3000;

    //public List<Data> arrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flights);

        recyclerView=findViewById(R.id.recycler);
        monthVal=findViewById(R.id.month);
        yearVal=findViewById(R.id.yearVal);
        dDate=findViewById(R.id.date);

        Bundle bundle=getIntent().getExtras();
        selectedDate=bundle.getString("date");
        Log.d(TAG, "asdasd "+selectedDate);
    }

    @Override
    public void onResume() {
        super.onResume();
        getData();
    }

    public void getData(){
        ArrayList dayList,dateList,monthList,yearList,priceList;

        dayList=new ArrayList<>();
        dateList=new ArrayList<>();
        monthList=new ArrayList<>();
        yearList=new ArrayList<>();
        priceList=new ArrayList<>();

        calendar=Calendar.getInstance();

        for(int j=0;j<=365;j++){

            Date d=calendar.getTime();
            String dt=d.toString();
            Log.d(TAG, "getData: "+dt);
            calendar.add(Calendar.DATE,1);
            day=dt.substring(0,3);
            date=dt.substring(8,10);
            Log.d(TAG, "getData: "+date);
            date.replace("-","0");
            month=dt.substring(4,7);
            year=dt.substring(dt.length()-4);
            dayList.add(day);
            dateList.add(date);
            monthList.add(month);
            yearList.add(year);
            priceList.add(price);
            price++;

        }

        Date d=Calendar.getInstance().getTime();
        String todayDate=d.toString();

        recyclerViewAdapter=new RecyclerViewAdapter(dayList,dateList,monthList,yearList,priceList,selectedDate,todayDate,this,this,getApplicationContext());
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(recyclerViewAdapter);
    }

    @Override
    public void onClick(int position) {
    }

    @Override
    public void monthPosition(String month) {
        monthVal.setText(month);
    }

    @Override
    public void getYear(String year) {
        yearVal.setText(year);
    }
}
