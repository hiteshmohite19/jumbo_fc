package com.hitesh.ofcwork;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Date;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    ArrayList dayList,dateList,yearList,monthList,priceList;
    String TAG="project";
    ClickListener clickListener;
    GetMonth getMonth;
    String month,year,price,day,date,todayDate;
    String selectedDate,finalDate;
    Context context;
    String[] mMonthList={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    int row=-1,count=0;

    public RecyclerViewAdapter(ArrayList dayList, ArrayList dateList,ArrayList monthList,ArrayList yearList,ArrayList priceList,String selectedDate,String todayDate,GetMonth getMonth,ClickListener clickListener,Context context) {
        this.dayList = dayList;
        this.dateList = dateList;
        this.monthList=monthList;
        this.yearList=yearList;
        this.priceList=priceList;
        this.todayDate=todayDate;
        this.clickListener=clickListener;
        this.getMonth=getMonth;
        this.context=context;
        this.selectedDate=selectedDate;
        Log.d(TAG, "RecyclerViewAdapter: "+this.selectedDate);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_recycler_view_adapter,parent,false);
        return new ViewHolder(view,clickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {

        day=String.valueOf(dayList.get(position));
        date=String.valueOf(dateList.get(position));
        holder.day.setText(day);
        holder.date.setText(date);
        month=String.valueOf(monthList.get(position));
        year=String.valueOf(yearList.get(position));
        holder.price.setText(String.valueOf(priceList.get(position)));

        getMonth.monthPosition(month);
        getMonth.getYear(year);
//        holder.mMonth.setText(month);

        if(count==0){
            selectedDate(holder,position);
            //count++;
        }
        if(count!=0){
            dateSelectedOnClick(holder,position);
        }

        holder.cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                row=position;
                count++;
                notifyDataSetChanged();
            }
        });
        todayDate(holder);
        //flights.monthVal.setText("dum");
    }

    // selected date
    void selectedDate(ViewHolder holder,int position){
        String dDay,dMonth,dDate,yYear;
        dDate=selectedDate.substring(selectedDate.length()-2);
        dMonth=selectedDate.substring(5,7);
        yYear=selectedDate.substring(0,4);
        int monthPos=Integer.parseInt(dMonth);



        if(finalDate==null)
            finalDate= dDate+" "+mMonthList[monthPos-1]+" "+yYear;
        Log.d(TAG, "finalDate: "+finalDate);

        Log.d(TAG, "selectedDate: "+date+month+year+" "+dDate+mMonthList[monthPos-1]+yYear);

        if(date.equals(dDate)&&month.equals(mMonthList[monthPos-1])&&year.equals(yYear)){
            Log.d(TAG, "selectedDate: "+position);
            holder.date.setTextColor(Color.parseColor("#FFFFFF"));
            holder.date.setBackground(context.getResources().getDrawable(R.drawable.date_background));
            //flights.monthVal.setText(dMonth);
        } else{
            holder.date.setBackgroundColor(Color.parseColor("#FFFFFF"));
            holder.date.setTextColor(Color.parseColor("#000000"));
        }
    }

    // dateSelected
    void dateSelectedOnClick(ViewHolder holder,int position){
        if(row==position){
            holder.date.setTextColor(Color.parseColor("#FFFFFF"));
            holder.date.setBackground(context.getResources().getDrawable(R.drawable.date_background));
            finalDate=dateList.get(position)+" "+monthList.get(position)+" "+yearList.get(position);
            //flights.monthVal.setText(monthList.get(position).toString());
            Log.d(TAG, "final date: "+finalDate);
        } else{
            holder.date.setBackgroundColor(Color.parseColor("#FFFFFF"));
            holder.date.setTextColor(Color.parseColor("#000000"));
        }
    }


    void todayDate(ViewHolder holder){
        String dDay,dMonth,dDate,yYear;
        dDay=todayDate.substring(0,3);
        dDate=todayDate.substring(8,10);
        dMonth=todayDate.substring(4,7);
        yYear=todayDate.substring(todayDate.length()-4);

        if(date.equals(dDate)&&month.equals(dMonth)&&year.equals(yYear)){
            holder.date.setTextColor(Color.parseColor("#E52235"));
            //holder.date.setBackground(context.getResources().getDrawable(R.drawable.first_date));
        }
//        else{
//            holder.date.setBackgroundColor(Color.parseColor("#FFFFFF"));
//            holder.date.setTextColor(Color.parseColor("#000000"));
//        }
    }


    @Override
    public int getItemCount() {
        return dateList.size();
    }



    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView day,date,price;
        CardView cardview;
        ClickListener clickListener;
        GetMonth getMonth;
        Date todayDate=new Date();
        String tDate=todayDate.toString();
        private static final String TAG = "project";

        public ViewHolder(@NonNull View itemView,ClickListener clickListener) {
            super(itemView);
            day=itemView.findViewById(R.id.day);
            date=itemView.findViewById(R.id.date);
            price=itemView.findViewById(R.id.price);
            cardview=itemView.findViewById(R.id.cardview);

            this.clickListener=clickListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            clickListener.onClick(getAdapterPosition());
        }

    }

    public interface ClickListener{
        void onClick(int position);
    }

    public interface GetMonth{
        void monthPosition(String month);
        void getYear(String year);
    }
}
